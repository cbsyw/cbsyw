'use strict'

function myFunction() {
    var myVar1 = document.querySelector(".nav-toggler")
    var myVar2 = document.querySelector(".menu")
    myVar1.classList.toggle("active");
    myVar2.classList.toggle("active");
}


